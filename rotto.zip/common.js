function hr(){
    document.write("<hr>")
}
function br(){
    document.write("<br>")
}
function dw(str){
    document.write(str)
}